package calendar;

/**
 * Class for Weekdays
 * @author Mara
 */
public enum Weekday {
	
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY

}
