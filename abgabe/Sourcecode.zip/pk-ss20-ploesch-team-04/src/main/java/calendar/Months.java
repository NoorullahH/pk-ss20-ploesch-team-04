package calendar;

/**
 * Class for Months
 * @author Mara
 */
public enum Months {
	
	JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
	
}
