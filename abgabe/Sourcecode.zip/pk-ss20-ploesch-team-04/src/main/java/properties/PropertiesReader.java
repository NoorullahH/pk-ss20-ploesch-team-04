package properties;
import java.util.*;
/**
 * @author Dino
 * @version 1
 */

public interface PropertiesReader {
	public static Properties get(String fileName) {
		return null;
	}
}
