# pk-ss20-ploesch-team-04
## Johannes Kepler Universität Linz
## Institut für Wirtschaftsinformatik - Software Engineering
## Gruppe 4
